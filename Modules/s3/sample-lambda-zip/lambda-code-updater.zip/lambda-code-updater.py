import boto3
import os

#Initializing boto3 client and fetching environment variable values
s3_client = boto3.client('s3')
lambda_client = boto3.client('lambda')
prefix = os.environ['ENTITY_NAME']

def lambda_handler(event, context):
  """
      This is the entry point of Lambda which will get trigger on S3 object notification
  """
  
  #Capturing the input event data
  bucket_name = event['Records'][0]['s3']['bucket']['name']
  file_name = event['Records'][0]['s3']['object']['key']
  
  try:
    #Fetching the environment type value from source bucket name
    if bucket_name.startswith(prefix):
      parts = bucket_name[len(prefix):].split('-')
      if len(parts) > 0:
        environment = parts[1]
        print(f'Environment: {environment}')
      else:
        print('Environment part not found in the bucket name. Please check your bucket name if it contains the environment name')
        return False
    else:
      print('Bucket name does not start with the expected entity name')
      return False
    
    #Forming the target Lambda function name to be updated
    extracted_file_name = file_name.split('/')[-1].split('.')[0]
    target_lambda_function_name = '-'.join([prefix, environment, extracted_file_name])

    #Getting the latest version ID of S3 object of source code files
    get_version = s3_client.get_object(
              Bucket = bucket_name,
              Key = file_name
              )
    version_id = (get_version['VersionId'])

    #Updating the target Lambda function code with the latest code
    update_lambda = lambda_client.update_function_code(
                      FunctionName=target_lambda_function_name,
                      S3Bucket=bucket_name,
                      S3Key=file_name,
                      S3ObjectVersion=version_id
                      )
    print(f'Lambda function code for {target_lambda_function_name} function is updated successfully')
    return True

  except Exception as exception:
    print(f'Error occurred while updating Lambda function code {exception}. Please check CloudWatch logs for more details.')
    return False